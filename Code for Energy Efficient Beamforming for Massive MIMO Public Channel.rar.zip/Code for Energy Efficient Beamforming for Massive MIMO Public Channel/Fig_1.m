% comparison
% my algorithm
% baseline 1: yeli
% baseline 2: xingmeng
% zc 170126 update
clc;clear;
M=64; % antenna number
D=4/8; % antenna space ratio 3/8
% the grid for spatial frequency
% k=1:2*M-1;
% sin_theta=2*(k-M)./(2*M-1);
sin_theta=linspace(-1,1,3*M); %3*M
% define the ideal magnitude response (trapezium)
Cs=1; % the power of beamformer
Theta_min=deg2rad(-30); % right bound of passband (rad)
Theta_max=deg2rad(+30); % left bound of passband （rad）
sibe_dec=15; % the decrease in magnitude (dB) for sidelobe (corresponding decrease in power beam pattern is 2*sibe_dec)
trans_width_deg=4;%1:3:15; % 4
% delta_mag_s=[-0.06,-0.03,0,0.03,0.06];
trans_width_s=deg2rad(trans_width_deg); %10:-2:0 % the width of transition band (rad)

% figure;
L_tran=length(trans_width_s);
% L_tran=length(delta_mag_s);
perf=zeros(1,L_tran);
for iL=1:L_tran
    %%%%%%%%%%%%%%%%%%%
    trans_width=trans_width_s(iL);
    %%%%%%%%%%%%%%%%%%%
%     trans_width=degtorad(4);
%     delta_mag=delta_mag_s(iL);
    %%%%%%%%%%%%%%%%%%%
    % ideal beam pattern
    [f_main,f_tranl,f_stopl,f_tranr,f_stopr,ideal_mag,sigma,f_main_ind]=...
        function_ideal_beam_pattern_in_spatial_frequency(D,sin_theta,Cs,Theta_min,...
        Theta_max,trans_width,sibe_dec);
    %%%%%%%%%%%%%%%%%%% 
    % creat array repsonse vectors
    arvm=getulaaarv_zc(M,f_main,D);
    arvs=getulaaarv_zc(M,[f_stopl,f_stopr],D);
    
    % the proposed algorithm
    th=10^(-10); % threshold for convergence
    itern1=5;
    itern2=5;
    if length([f_stopl,f_stopr])==0
        [w,eps]=Algorithm_2_semidefinite_all_pass(arvm,Cs,ideal_mag,th,itern1,itern2,M);
    else
        [w,eps]=Algorithm_2_semidefinite(arvs,arvm,Cs,ideal_mag,sigma,th,itern1,itern2,M);
%         [w,eps]=Algorithm_2_semidefinite_per_antenna_constraint(arvs,arvm,Cs,ideal_mag,sigma,th,itern1,itern2,M);
    end
    w1=w;
    eps1=eps;
    sin_theta_fig=sin_theta;
    [~,m_s]=min(abs(f_main(1)-sin_theta_fig));
    [~,m_e]=min(abs(f_main(end)-sin_theta_fig));
    arvp=getulaaarv_zc(M,sin_theta_fig,D);
    y1=w1'*arvp;
    y1abs=abs(y1);
    perf1(iL)=min(y1abs(m_s:m_e));
    figure
    plot(sin_theta_fig,y1abs.^2,'LineWidth',2);grid on;

    
    % baseline 1 ideal beampattern

    hold on
    plot(sin_theta,([sigma*ones(1,length([f_stopl,f_tranl])),...
        ideal_mag*ones(1,length(f_main)),sigma*ones(1,length([f_tranr,f_stopr]))].^2),'linewidth',2);

    % baseline 2 [3]
    w3=1/sqrt(M)*exp(1i*pi*1*(0:M-1).^2/M).';
    sin_theta_fig=linspace(-1,1,3*M); %
    [~,m_s]=min(abs(f_main(1)-sin_theta_fig));
    [~,m_e]=min(abs(f_main(end)-sin_theta_fig));
    arvp=getulaaarv_zc(M,sin_theta_fig,D);
    y1=w1'*arvp;
    y1abs=abs(y1);
    perf(iL)=min(y1abs(m_s:m_e));
    y3=w3'*arvp;
    y3abs=abs(y3);
    hold on;
    plot(sin_theta_fig,y3abs.^2,'b-','LineWidth',2);


    % baseline 4 
    itern=50;
    ini_s=1;
    [w,eps]=Direct_algorithm(arvs,arvm,Cs,ideal_mag,sigma,th,itern,M,w1,ini_s);
    w2=w;
    y2=w2'*arvp;
    y1abs2=abs(y2);
%     perf2(it,1)=min(y1abs2(m_s:m_e));
    hold on;
    plot(sin_theta_fig,y1abs2.^2,'LineWidth',2);

    % baseline 3 180全通
            [f_main,f_tranl,f_stopl,f_tranr,f_stopr,ideal_mag,sigma,f_main_ind]=...
        function_ideal_beam_pattern_in_spatial_frequency(D,sin_theta,Cs,deg2rad(-90),...
        deg2rad(90),trans_width,sibe_dec);
    % creat array repsonse vectors
    arvm=getulaaarv_zc(M,f_main,D);
    arvs=getulaaarv_zc(M,[f_stopl,f_stopr],D);
    if length([f_stopl,f_stopr])==0
        [w,eps]=Algorithm_2_semidefinite_all_pass(arvm,Cs,ideal_mag,th,itern1,itern2,M);
    else
        [w,eps]=Algorithm_2_semidefinite_new_constraint_1(arvs,arvm,Cs,ideal_mag,sigma,th,itern1,itern2,M);
    end
    w4=w;
    eps2=eps;
    y4=w4'*arvp;
    y1abs4=abs(y4);
    perf2(iL)=min(y1abs4(m_s:m_e));
    hold on;
    plot(sin_theta_fig,y1abs4.^2,'LineWidth',2);


end
%     xlabel('sin(\theta)');ylabel('波束响应值');
%     title('[-90^{\circ},90^{\circ}]，\Delta_T=4^{\circ}');
xlabel('sin(\theta)');ylabel('beam pattern');grid on;
legend('60\circ,P3','60\circ,ideal','[3]','60\circ,P4','180\circ, P3');
axis([-1,1,0,2.2])