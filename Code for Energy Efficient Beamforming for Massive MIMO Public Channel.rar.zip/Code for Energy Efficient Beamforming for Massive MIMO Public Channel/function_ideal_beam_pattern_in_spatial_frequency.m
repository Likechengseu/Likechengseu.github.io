% input: 
% output:
% zc 170126
function [f_main,f_tranl,f_stopl,f_tranr,f_stopr,ideal_mag,sigma,f_main_ind]=...
    function_ideal_beam_pattern_in_spatial_frequency(D,sin_theta,Cs,Theta_min,...
    Theta_max,trans_widht,sibe_dec)
Lt=length(sin_theta);
% spatial frequency (SF) points of mainlobe
f_main_ind=find(sin_theta>=sin(Theta_min) & sin_theta<=sin(Theta_max));
f_main=sin_theta(f_main_ind);
% SF points of transition and stop band
% lefthand
[~,I]=min(abs(sin(Theta_min-trans_widht)-sin_theta));
if I>f_main_ind(1)-1
    f_tranl=[];
    if f_main_ind(1)>1
        f_stopl=sin_theta(1:f_main_ind(1)-1);
    else
        f_stopl=[];
    end
else
    f_tranl=sin_theta(I:f_main_ind(1)-1);
    if I>1
        f_stopl=sin_theta(1:I-1);
    else
        f_stopl=[];
    end
end
% righthand
[~,I]=min(abs(sin(Theta_max+trans_widht)-sin_theta));
if I<f_main_ind(end)+1
    f_tranr=[];
    if f_main_ind(end)<Lt
        f_stopr=sin_theta(f_main_ind(end)+1:Lt);
    else
        f_stopr=[];
    end
else
    f_tranr=sin_theta(f_main_ind(end)+1:I);
    if I<Lt
        f_stopr=sin_theta(I+1:Lt);
    else
        f_stopr=[];
    end
end

% calculate ideal beam pattern in the mainlobe
L_M=2*pi*D*(sin(Theta_max)-sin(Theta_min));
ideal_mag=sqrt(2*pi*Cs/(L_M)); 
% the maximum beam pattern (root) for sidelobe
sigma=ideal_mag/10^(sibe_dec/10); % the demand on stopband


