% Algorithm II in "Optimal Array Pattern Synthesis Using Semidefinite Programming"
% zc 170125
% input
% arvs: array repsonse vectors for the stop band
% arvm: array repsonse vectors for the pass band
% Cs: the maximum tranmit power
% ideal_mag: ideal magnitude response in mainlobe
% sigma: maximum value in stop band
% th: theshold for convergence
% itern1: maximum iterative number for re-initialization
% itern2: maximum iterative number for Algorithm I
% output
% w_o:optimized weight vector
% eps:maximum error in mainlobe
function [w_o,eps_store]=Algorithm_2_semidefinite(arvs,arvm,Cs,ideal_mag,sigma,th,itern1,itern2,M)
eps_store=[];
% step 1) initialization
cvx_begin quiet
variable w(M) complex;
variable delta1;
minimize delta1;
subject to
norm(w'*arvs,Inf)<=sigma;
norm(w'*arvm-ideal_mag,Inf)<=delta1;
norm(w)<=sqrt(Cs);
cvx_end
w_o=w;
eps0=norm(abs(w_o'*arvm)-ideal_mag,Inf); % the maximum error for initialization
w_1=w_o/2;
eps_store=[eps_store,eps0];
% step 2) iterative
for ni=1:itern1
    % apply Algorithm I
    for idx=1:itern2
        disp('itern2');
        disp(idx);
        
        cvx_begin quiet
        variable w_2(M) complex;
        variable delta1;  
        minimize delta1;        
        subject to
        norm((w_1+w_2)'*arvm,Inf) <= ideal_mag+delta1;
        min(sqrt(4*real(w_1'*arvm.*conj(w_2'*arvm))))>=max(0,ideal_mag-delta1);
        norm((w_1+w_2)'*arvs,Inf)<=sigma;
        norm(w_1+w_2)<=sqrt(Cs);
        cvx_end      
        disp(cvx_optval);
        
        cvx_begin quiet
        variable w_1(M) complex;
        variable delta1;
        minimize delta1;
        subject to
        norm((w_1+w_2)'*arvm,Inf) <= ideal_mag+delta1;
        min(sqrt(4*real(w_1'*arvm.*conj(w_2'*arvm))))>=max(0,ideal_mag-delta1);
        norm((w_1+w_2)'*arvs,Inf)<=sigma;
        norm(w_1+w_2)<=sqrt(Cs);
        cvx_end
        
        w=w_1+w_2;
        eps=norm(abs(w'*arvm)-ideal_mag,Inf);
        % determinate condition
        if eps>eps0
            disp('break');break;
        else
            w_o=w;
            if eps0-eps<=th
                disp('break');break;
            end
            eps0=eps;
            eps_store=[eps_store,eps0];
        end
    end
    
    % Step 3
    % adjust the phase based on the former result
    dres=w_o'*arvm;
    resp=angle(dres); %phase
    resn=ideal_mag*exp(sqrt(-1)*resp);
    
    cvx_begin quiet
    variable w(M) complex;
    variable delta1;
    minimize delta1;
    subject to
    norm(w'*arvs,Inf)<=sigma;
    norm(w'*arvm-resn,Inf)<=delta1;
    norm(w)<=sqrt(Cs);
    cvx_end
    eps=norm(abs(w'*arvm)-ideal_mag,Inf); % the maximum error for initialization
    if eps>eps0
        disp('break');break;
    else
        w_o=w;
        w_1=w_o/2;
        if eps0-eps<=th
            disp('break');break;
        end
        eps0=eps;
        eps_store=[eps_store,eps0];
    end
end

