% creat array repsonse vectors
% input 
% N_BS: Bs antenna number
% theta: angle sine value
% D: antenna space ratio
% output
% ares: normalized array vectors
function ares=getulaaarv_zc(N_BS,theta,D)

vi=sqrt(-1);
%��ȡ������Ӧ����
nAngle=length(theta);   %�Ƕ���Ŀ

ares=zeros(N_BS,nAngle);
for k=1:nAngle
    a=exp(-vi*2*pi*D*theta(k)*[0:N_BS-1]');
    ares(:,k)=a; %/sqrt(N_BS)
end
